print("extructuras repetitiva ejercicio 3")
for i in range(5,15000):
    print ("el valor de i es ",i)
