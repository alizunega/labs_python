print("extructuras repetitiva ejercicio 1")
for i in range(100):
    print ("el valor de i es ",i)
