print("Extructuras Selectivas-Punto 6")
val1=int(input("ingrese el primer valor "))
val2=int(input("ingrese  el segundo valor "))
if val1==1:        
    val3=100*val2
    print("el valor obtenido es: ",val3)
elif val1==2:
     val3=100%val2
     print("el valor obtenido es: ",val3)
elif val1 ==3:
     val3=100/val2
     print("el valor obtenido es: ",val3)
         
else:
    print("el valor obtenido es 0")
