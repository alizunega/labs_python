print("Extructuras Selectivas-Punto 4")
numero=int(input("ingrese un numero: "))
if ((numero%2)==0):
    print("el numero es par")
else:
    print("el numero es impar")
