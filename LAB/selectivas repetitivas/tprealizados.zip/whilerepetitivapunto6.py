print("Extructuras repetitivas while, punto 6")
i=1
while i<=30:
   print("el cuadrado de los primeros 30 numeros naturales> ")
   cuad=i*i
   print(i,cuad)
   i+=1
