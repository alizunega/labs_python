print("Extructuras repetitivas while, punto 2")
i=5
while i<=10:
   print("el valor de i es: ",i)
   i+=1
