print("Extructuras Selectivas-Punto 2")
sueldo=float(input("ingrese el sueldo del trabajador: "))
if sueldo<3500:
    sueldo=sueldo+sueldo*0.25
    print("el sueldo del trabajador es: ",sueldo)
else:
    print("el sueldo del trabajador es: ",sueldo)
