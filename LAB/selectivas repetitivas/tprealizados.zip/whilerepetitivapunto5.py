print("Extructuras repetitivas while, punto 2")
i=1
while i<=200:
   print(i,"hola")
   i+=1
