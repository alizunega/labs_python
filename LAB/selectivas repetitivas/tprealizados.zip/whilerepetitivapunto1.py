print("repetitiva con while ejercicio 1")
i=1
while i <= 100:
        print("el valor de i es : ",i)
        i+=1
