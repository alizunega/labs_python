print("Extructuras Selectivas-Punto 5")
dia=int(input("ingrese el dia de nacimiento de la persona: "))
mes=int(input("ingrese el mes de nacimiento de la persona: "))
if mes==1:        
    if dia>21:
        print("el signo es acuario")
    else:
        print("el signo es capricornio")
elif mes==2:
     if dia>21:
         print("el signo es de piscis")
     else:
         print("el signo es de acuario")
elif mes ==3:
     if dia>21:
         print("el signo es de Aries")
     else:
         print("el signo es de Piscis")
elif mes ==4:
     if dia>21:
         print("el signo es de Tauro")
     else:
         print("el signo es de Aries")
elif mes ==5:
     if dia>21:
         print("el signo es de Geminis")
     else:
         print("el signo es de Tauro")
elif mes ==6:
     if dia>21:
         print("el signo es de Cancer")
     else:
         print("el signo es de Geminis")
elif mes ==7:
     if dia>21:
         print("el signo es de Leo")
     else:
         print("el signo es de Cancer")
elif mes ==8:
     if dia>21:
         print("el signo es de Virgo")
     else:
         print("el signo es de Leo")
elif mes ==9:
     if dia>21:
         print("el signo es de Libra")
     else:
         print("el signo es de Virgo")
elif mes ==10:
     if dia>21:
         print("el signo es de Escorpio")
     else:
         print("el signo es de Libra")
elif mes ==11:
     if dia>21:
         print("el signo es de Sagitario")
     else:
         print("el signo es de Escorpio")
elif mes ==12:
     if dia>21:
         print("el signo es de Capricornio")
     else:
         print("el signo es de Sagitario")
         
else:
    print("error, mes invalido")
