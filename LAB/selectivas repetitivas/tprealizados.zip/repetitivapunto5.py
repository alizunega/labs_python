print("extructuras repetitiva ejercicio 5")
for i in range(200):
    print ("el valor de i es ",i,"hola")
