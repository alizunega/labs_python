print("extructuras repetitiva ejercicio 6")
for i in range(30):
    cuad=i*i
    print("cuadrado de los 30 primeros numeros naturales: ")
    print(i,cuad)
