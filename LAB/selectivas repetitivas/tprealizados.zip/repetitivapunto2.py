print("extructuras repetitiva ejercicio 2")
for i in range(5,10):
    print ("el valor de i es ",i)
