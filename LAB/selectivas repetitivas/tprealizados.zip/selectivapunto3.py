print("Extructuras Selectivas-Punto 3")
sueldo2=float(input("ingrese el sueldo del trabajador: "))
if sueldo2<5000:
    sueldo2=sueldo2+sueldo2*0.30
    print("el sueldo del trabajador es: ",sueldo2)
else:
    sueldo2=sueldo2+sueldo2*0.15
    print("el sueldo del trabajador es: ",sueldo2)
