print("extructuras repetitiva ejercicio 9")
conta=0
conte=0
conti=0
conto=0
contu=0
for i in range(20):
    letra=input("ingrese una letra: ")
    if letra=="a":
        conta=conta+1
    elif letra=="e":
         conte=conte+1
    elif letra=="i":
         conti=conti+1
    elif letra=="o":
         conto=conto+1
    elif letra=="u":
         contu=contu+1
    else:
        print("introdujo una letra mal")
print("la cantidad de letras a ingresadas: ", conta)
print("la cantidad de letras e ingresadas: ", conte)
print("la cantidad de letras i ingresadas: ", conti)
print("la cantidad de letras o ingresadas: ", conto)
print("la cantidad de letras u ingresadas: ", contu)
