print("Extructuras Selectivas-Punto 1")
calif=int(input("ingrese calificacion alumno: "))
if calif>8:
    print("el alumno esta aprobado")
else:
    print("el alumno no esta aprobado")
